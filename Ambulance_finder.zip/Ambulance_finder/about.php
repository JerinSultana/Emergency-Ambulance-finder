<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us — AmbuFinder</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Poppins',sans-serif; background:#ffffff; color:#333; }

/* Navbar */
header {
  position:fixed;
  width:100%;
  top:0;
  left:0;
  background:#ffffff;
  box-shadow:0 4px 12px rgba(0,0,0,0.05);
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:15px 60px;
  z-index:1000;
}

.logo { display:flex; align-items:center; gap:12px; font-weight:700; color:#dc3545; font-size:28px; }
.logo img { width:150px; height:150px; border-radius:50%; object-fit:cover; border:3px solid #dc3545; }

nav ul { list-style:none; display:flex; gap:25px; align-items:center; }
nav a { text-decoration:none; color:#333; font-weight:600; font-size:16px; transition: color 0.3s; }
nav a:hover { color:#dc3545; }
.download-btn { background:#dc3545; color:#fff; padding:8px 16px; border-radius:8px; font-weight:600; text-decoration:none; transition:background 0.3s; }
.download-btn:hover { background:#b71c1c; }

/* Content Section */
.content { padding:180px 60px 60px; max-width:900px; margin:auto; line-height:1.6; }
.content h1 { font-size:36px; color:#dc3545; margin-bottom:20px; }
.content p { font-size:18px; color:#555; margin-bottom:15px; }

/* Footer */
footer { text-align:center; padding:25px; background:#ffffff; color:#555; font-size:15px; box-shadow:0 -2px 8px rgba(0,0,0,0.05); }

/* Responsive */
@media(max-width:900px){
  .content { padding:180px 20px 40px; }
  .content h1 { font-size:28px; }
  nav ul { display:none; }
}
</style>
</head>
<body>

<header>
  <div class="logo">
    <img src="AmbuFinder_LOGO.png" alt="AmbuFinder Logo">
    AmbuFinder
  </div>
  <nav>
    <ul>
      <li><a href="home.php">Home</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="services.php">Services</a></li>
      <li><a href="userlogin.php">Login</a></li>
      <li><a href="register.php">Sign Up</a></li>
      <li><a href="#" class="download-btn">Download App</a></li>
    </ul>
  </nav>
</header>

<section class="content">
  <h1>About AmbuFinder</h1>
  <p>AmbuFinder is a modern emergency ambulance service dedicated to saving lives. Our mission is to provide fast, reliable, and life-saving ambulance services across the city, ensuring you or your loved ones reach medical aid in time.</p>
  <p>All our ambulances are fully equipped with essential medical devices and staffed with trained paramedics. We are committed to maintaining safety, efficiency, and trust in every emergency situation.</p>
  <p>AmbuFinder continues to innovate in emergency medical services to ensure that no patient is left behind, and help is always just a call away.</p>
</section>

<footer>
  © 2025 AmbuFinder | Emergency Ambulance Service
</footer>

</body>
</html>
