<?php
include 'includes/db_connect.php';

if(isset($_GET['q'])){
    $query = mysqli_real_escape_string($conn,$_GET['q']);
    $sql = "SELECT DISTINCT name FROM ambulances WHERE name LIKE '%$query%' LIMIT 5";
    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            echo "<div onclick=\"selectSuggestion('".htmlspecialchars($row['name'])."')\">".$row['name']."</div>";
        }
    } else {
        echo "<div>No matching ambulances found</div>";
    }
}
?>




