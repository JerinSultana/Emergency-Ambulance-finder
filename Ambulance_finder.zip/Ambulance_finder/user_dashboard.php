<?php
session_start();
include 'includes/db_connect.php';

// SESSION SECURITY
session_regenerate_id(true); // prevent session fixation
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// CSRF token for forms
if(empty($_SESSION['csrf_token'])){
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// FETCH USER BOOKINGS SECURELY
$stmt = $conn->prepare("SELECT id, pickup, drop_location, status FROM bookings WHERE user_id=? ORDER BY booking_time DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Dashboard | AmbuFinder</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
/* CSS same as your previous code */
body { font-family:'Poppins',sans-serif; background:#f1f3f6; margin:0; }
nav { background:#dc3545; color:#fff; padding:12px 20px; display:flex; justify-content:space-between; align-items:center; }
nav h2 { margin:0; font-size:22px; }
.lang-btn { background:#fff; border:none; border-radius:8px; padding:6px 10px; cursor:pointer; font-weight:600; }
.container { max-width:900px; margin:30px auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 5px 15px rgba(0,0,0,0.1); }
h3 { color:#dc3545; text-align:center; }
table { width:100%; border-collapse:collapse; margin-top:15px; }
table th, table td { border:1px solid #ddd; padding:10px; text-align:center; }
table th { background:#dc3545; color:white; }
button { background:#28a745; color:#fff; border:none; border-radius:6px; padding:8px 14px; cursor:pointer; }
button:hover { background:#218838; }

/* Feedback modal */
.modal { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); justify-content:center; align-items:center; }
.modal-content { background:#fff; padding:20px; border-radius:12px; max-width:400px; width:90%; text-align:center; }
.star { font-size:30px; cursor:pointer; color:#ccc; }
.star.selected { color:#ffc107; }
textarea { width:100%; padding:8px; margin-top:10px; border-radius:6px; border:1px solid #ccc; resize:none; }
.modal button { margin-top:12px; padding:8px 14px; border:none; border-radius:6px; cursor:pointer; background:#28a745; color:#fff; }
.modal button:hover { background:#218838; }
</style>
</head>
<body>

<nav>
  <h2 id="title">User Dashboard</h2>
  <button id="lang-toggle" class="lang-btn">বাংলা</button>
</nav>

<div class="container">
  <h3 id="sub">Your Recent Ambulance Bookings</h3>

  <?php if($result->num_rows > 0){ ?>
  <table>
    <tr>
      <th id="col1">Booking ID</th>
      <th id="col2">Pickup</th>
      <th id="col3">Drop</th>
      <th id="col4">Status</th>
      <th id="col5">Payment</th>
      <th>Feedback</th>
    </tr>
    <?php while($row = $result->fetch_assoc()){ ?>
    <tr>
      <td><?php echo (int)$row['id']; ?></td>
      <td><?php echo htmlspecialchars($row['pickup']); ?></td>
      <td><?php echo htmlspecialchars($row['drop_location']); ?></td>
      <td><?php echo htmlspecialchars($row['status']); ?></td>
      <td>
        <?php if($row['status']=='Pending'){ ?>
          <form action="payment.php" method="post">
            <input type="hidden" name="booking_id" value="<?php echo (int)$row['id']; ?>">
            <button type="submit">Pay Now</button>
          </form>
        <?php } else { echo "-"; } ?>
      </td>
      <td>
        <?php if($row['status']=='Completed'){ ?>
          <button onclick="openFeedbackModal(<?php echo (int)$row['id']; ?>)">Give Feedback</button>
        <?php } else { echo "-"; } ?>
      </td>
    </tr>
    <?php } ?>
  </table>
  <?php } else { ?>
    <p style="text-align:center; color:#555;" id="nobooking">No bookings found.</p>
  <?php } ?>
</div>

<!-- Feedback Modal -->
<div class="modal" id="feedbackModal">
    <div class="modal-content">
        <h3>Give Your Feedback</h3>
        <div id="stars">
            <span class="star" data-value="1">&#9733;</span>
            <span class="star" data-value="2">&#9733;</span>
            <span class="star" data-value="3">&#9733;</span>
            <span class="star" data-value="4">&#9733;</span>
            <span class="star" data-value="5">&#9733;</span>
        </div>
        <textarea id="feedbackComment" placeholder="Write your comment (optional)"></textarea>
        <input type="hidden" id="csrf_token" value="<?php echo $csrf_token; ?>">
        <button onclick="submitFeedback()">Submit</button>
        <button onclick="closeFeedbackModal()" style="background:#dc3545;margin-top:5px;">Cancel</button>
    </div>
</div>

<script>
// Language toggle (same as before)
const langToggle = document.getElementById('lang-toggle');
const langData = { en: { title:"User Dashboard", sub:"Your Recent Ambulance Bookings", col1:"Booking ID", col2:"Pickup", col3:"Drop", col4:"Status", col5:"Payment", nobooking:"No bookings found.", button:"বাংলা" }, bn: { title:"ব্যবহারকারী ড্যাশবোর্ড", sub:"আপনার সাম্প্রতিক অ্যাম্বুলেন্স বুকিংসমূহ", col1:"বুকিং আইডি", col2:"পিকআপ স্থান", col3:"গন্তব্য", col4:"অবস্থা", col5:"পেমেন্ট", nobooking:"কোনো বুকিং পাওয়া যায়নি।", button:"English" } };
let currentLang = localStorage.getItem('lang') || 'en';
updateLang();
langToggle.addEventListener('click',()=>{ currentLang=currentLang==='en'?'bn':'en'; localStorage.setItem('lang',currentLang); updateLang(); });
function updateLang(){ const l=langData[currentLang]; document.getElementById('title').textContent=l.title; document.getElementById('sub').textContent=l.sub; document.getElementById('col1').textContent=l.col1; document.getElementById('col2').textContent=l.col2; document.getElementById('col3').textContent=l.col3; document.getElementById('col4').textContent=l.col4; document.getElementById('col5').textContent=l.col5; langToggle.textContent=l.button; const nb=document.getElementById('nobooking'); if(nb) nb.textContent=l.nobooking; }

// Feedback system
let selectedBookingId=0; let selectedRating=0;
const stars=document.querySelectorAll('.star');

function openFeedbackModal(bookingId){ selectedBookingId=bookingId; document.getElementById('feedbackModal').style.display='flex'; selectedRating=0; stars.forEach(s=>s.classList.remove('selected')); document.getElementById('feedbackComment').value=''; }
function closeFeedbackModal(){ document.getElementById('feedbackModal').style.display='none'; }

stars.forEach(star=>{ star.addEventListener('mouseover',()=>{ highlightStars(parseInt(star.getAttribute('data-value'))); }); star.addEventListener('mouseout',()=>{ highlightStars(selectedRating); }); star.addEventListener('click',()=>{ selectedRating=parseInt(star.getAttribute('data-value')); highlightStars(selectedRating); }); });

function highlightStars(rating){ stars.forEach(s=>{ let val=parseInt(s.getAttribute('data-value')); if(val<=rating) s.classList.add('selected'); else s.classList.remove('selected'); }); }

function submitFeedback(){
    const comment=document.getElementById('feedbackComment').value;
    const csrf=document.getElementById('csrf_token').value;
    if(selectedRating===0){ alert('Please select a rating!'); return; }
    const xhr=new XMLHttpRequest();
    xhr.open('POST','feedback_handler.php',true);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.onload=function(){
        if(this.status==200){
            const res=JSON.parse(this.responseText);
            if(res.success){ alert('Feedback submitted successfully!'); closeFeedbackModal(); }
            else alert(res.message || 'Error submitting feedback!');
        }
    };
    xhr.send('booking_id='+selectedBookingId+'&rating='+selectedRating+'&comment='+encodeURIComponent(comment)+'&csrf_token='+csrf);
}
</script>

</body>
</html>
