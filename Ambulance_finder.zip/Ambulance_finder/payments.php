<?php
session_start();
include 'includes/db_connect.php';

if(!isset($_SESSION['user_id'])){
    header('Location: userlogin.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user's pending bookings
$booking_sql = "SELECT * FROM bookings WHERE user_id='$user_id' AND status='Pending'";
$booking_result = mysqli_query($conn, $booking_sql);
$booking_id = mysqli_num_rows($booking_result) > 0 ? mysqli_fetch_assoc($booking_result)['id'] : '';

// Handle payment form submission
if(isset($_POST['pay'])){
    $booking_id = $_POST['booking_id'];
    $amount = $_POST['amount'] ?? 0; // for Cash, amount can be 0 or driver will handle
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $payment_status = "Completed";
    $payment_time = date('Y-m-d H:i:s');

    $insert_sql = "INSERT INTO payments (booking_id, user_id, amount, payment_method, payment_status, payment_time) 
                   VALUES ('$booking_id', '$user_id', '$amount', '$payment_method', '$payment_status', '$payment_time')";

    if(mysqli_query($conn, $insert_sql)){
        mysqli_query($conn, "UPDATE bookings SET status='Confirmed' WHERE id='$booking_id'");
        $success = "Payment successful! Booking confirmed.";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Make Payment</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { font-family:'Poppins',sans-serif; background:#f1f3f6; margin:0; }
nav { background:#dc3545; color:white; padding:12px 20px; display:flex; justify-content:space-between; align-items:center; }
nav h2 { margin:0; font-size:22px; }
.lang-btn { background:#fff; border:none; border-radius:8px; padding:6px 10px; cursor:pointer; font-weight:600; }

.container { max-width:800px; margin:50px auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 6px 15px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#dc3545; margin-bottom:20px; }
.success { color:green; text-align:center; margin-bottom:10px; }
.error { color:red; text-align:center; margin-bottom:10px; }

.payment-methods { display:flex; justify-content:space-around; margin:20px 0; flex-wrap:wrap; gap:10px; }
.payment-method { display:flex; flex-direction:column; align-items:center; text-align:center; cursor:pointer; padding:10px; border-radius:12px; border:1px solid #ccc; transition:0.3s; width:120px; }
.payment-method:hover { background:#f8f9fa; }
.payment-method img { width:60px; margin-bottom:8px; }
.payment-method span { font-weight:600; }

/* Modal styling */
.modal { display:none; position:fixed; z-index:1000; left:0; top:0; width:100%; height:100%; overflow:auto; background:rgba(0,0,0,0.5); }
.modal-content { background:#fff; margin:10% auto; padding:20px; border-radius:12px; width:90%; max-width:400px; position:relative; }
.close { position:absolute; top:10px; right:15px; font-size:24px; font-weight:bold; color:#333; cursor:pointer; }
input[type=text], input[type=number] { width:100%; padding:12px; margin:10px 0; border-radius:8px; border:1px solid #ccc; }
button { width:100%; padding:12px; background:#28a745; color:#fff; border:none; border-radius:8px; font-size:16px; cursor:pointer; margin-top:10px; }
button:hover { background:#218838; }
</style>
</head>
<body>

<nav>
  <h2 id="pageTitle">Make Payment</h2>
  <button id="lang-toggle" class="lang-btn">বাংলা</button>
</nav>

<div class="container">
    <?php if(isset($success)) { echo "<div class='success' id='successMsg'>$success</div>"; } ?>
    <?php if(isset($error)) { echo "<div class='error' id='errorMsg'>$error</div>"; } ?>

    <h2 id="chooseTitle">Select Payment Method</h2>

    <div class="payment-methods">
        <div class="payment-method" data-method="bKash">
            <img src="bkash.png" alt="bKash">
            <span>bKash</span>
        </div>
        <div class="payment-method" data-method="Nagad">
            <img src="nagad.png" alt="Nagad">
            <span>Nagad</span>
        </div>
        <div class="payment-method" data-method="Rocket">
            <img src="rocket.png" alt="Rocket">
            <span>Rocket</span>
        </div>
        <div class="payment-method" data-method="Cash">
            <img src="cash.png" alt="Cash">
            <span>Cash</span>
        </div>
        <div class="payment-method" data-method="Card">
            <img src="card.png" alt="Card">
            <span>Card</span>
        </div>
    </div>
</div>

<!-- Modal for Payment -->
<div id="paymentModal" class="modal">
  <div class="modal-content">
    <span class="close" id="closeModal">&times;</span>
    <h3 id="modalTitle">Enter Payment Details</h3>
    <form method="POST" id="paymentForm">
        <input type="hidden" name="payment_method" id="paymentMethodInput">
        <input type="text" name="payment_number" id="paymentNumber" placeholder="Enter Number" required>
        <input type="number" name="amount" id="paymentAmount" placeholder="Enter Amount" required>
        <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
        <button type="submit" name="pay">Pay Now</button>
    </form>
  </div>
</div>

<script>
// Language toggle
const langToggle = document.getElementById('lang-toggle');
const langData = {
  en: { pageTitle: "Make Payment", chooseTitle: "Select Payment Method", successMsg: "Payment successful! Booking confirmed.", errorMsg: "Error occurred during payment.", button: "বাংলা" },
  bn: { pageTitle: "পেমেন্ট করুন", chooseTitle: "পেমেন্ট পদ্ধতি নির্বাচন করুন", successMsg: "পেমেন্ট সম্পন্ন হয়েছে! বুকিং নিশ্চিত করা হয়েছে।", errorMsg: "পেমেন্টের সময় একটি ত্রুটি ঘটেছে।", button: "English" }
};
let currentLang = localStorage.getItem('lang') || 'en';
updateLang();
langToggle.addEventListener('click', () => {
  currentLang = currentLang==='en'?'bn':'en';
  localStorage.setItem('lang',currentLang);
  updateLang();
});
function updateLang(){ 
  const l = langData[currentLang];
  document.getElementById('pageTitle').textContent = l.pageTitle;
  document.getElementById('chooseTitle').textContent = l.chooseTitle;
  langToggle.textContent = l.button;
  if(document.getElementById('successMsg')) document.getElementById('successMsg').textContent=l.successMsg;
  if(document.getElementById('errorMsg')) document.getElementById('errorMsg').textContent=l.errorMsg;
}

// Payment modal
const modal = document.getElementById('paymentModal');
const closeModal = document.getElementById('closeModal');
const paymentMethods = document.querySelectorAll('.payment-method');
paymentMethods.forEach(method=>{
  method.addEventListener('click',()=>{
    const selectedMethod = method.getAttribute('data-method');

    // For Cash, directly submit form without modal
    if(selectedMethod === "Cash"){
        document.getElementById('paymentMethodInput').value = "Cash";
        document.getElementById('paymentAmount').value = 0; // amount can be 0 for Cash
        document.getElementById('paymentForm').submit();
        return;
    }

    document.getElementById('paymentMethodInput').value = selectedMethod;
    document.getElementById('modalTitle').textContent = "Pay with "+selectedMethod;
    document.getElementById('paymentNumber').style.display = "block";
    document.getElementById('paymentNumber').required = true;
    document.getElementById('paymentAmount').required = true;

    modal.style.display = "block";
  });
});

closeModal.onclick = ()=>{ modal.style.display='none'; }
window.onclick = e => { if(e.target==modal) modal.style.display='none'; }
</script>

</body>
</html>
