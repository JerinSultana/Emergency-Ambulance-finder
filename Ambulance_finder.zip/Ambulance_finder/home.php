<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AmbuFinder — Emergency Ambulance Service</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }

body {
  font-family:'Poppins',sans-serif;
  background:#ffffff;
  color:#333;
}

/* ===== Navbar ===== */
header {
  position:fixed;
  width:100%;
  top:0;
  left:0;
  background:#ffffff;
  box-shadow:0 4px 12px rgba(0,0,0,0.08);
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:18px 70px;
  z-index:1000;
  height:140px;
}

.logo {
  display:flex;
  align-items:center;
  gap:12px;
  font-weight:700;
  color:#dc3545;
  font-size:28px;
}

.logo img {
  width:130px;
  height:130px;
  border-radius:50%;
  object-fit:cover;
  border:3px solid #dc3545;
}

nav ul {
  list-style:none;
  display:flex;
  gap:28px;
  align-items:center;
}

nav a {
  text-decoration:none;
  color:#333;
  font-weight:600;
  font-size:16px;
  transition: color 0.3s;
}

nav a:hover { color:#dc3545; }

.download-btn {
  background:#dc3545;
  color:#fff;
  padding:9px 18px;
  border-radius:8px;
  font-weight:600;
  text-decoration:none;
  transition:background 0.3s;
}

.download-btn:hover { background:#b71c1c; }

/* ===== Hero Section ===== */
.hero {
  display:flex;
  align-items:center;
  justify-content:center;
  flex-direction:column;
  text-align:center;
  padding:170px 60px 100px;
  min-height:100vh;
}

.hero-content {
  display:flex;
  align-items:center;
  justify-content:center;
  gap:70px;
  flex-wrap:wrap;
  margin-top:40px;
}

.hero-text {
  max-width:520px;
  text-align:left;
}

.hero-text h1 {
  font-size:50px;
  font-weight:700;
  color:#dc3545;
  line-height:1.2;
  margin-bottom:20px;
}

.hero-text p {
  font-size:18px;
  color:#555;
}

/* ===== Hero Video Styling ===== */
.hero-video {
  flex: 1;
  min-width: 300px;
  max-width: 500px;
  border-radius: 20px;
  overflow: hidden;
  box-shadow: 0 8px 20px rgba(0,0,0,0.1);
  animation: fadeIn 2s ease-in-out;
}

.hero-video video {
  width: 100%;
  height: auto;
  border-radius: 20px;
  object-fit: cover;
  outline: none;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ===== Footer Section ===== */
.footer-section {
  background:#dc3545;
  color:#fff;
  padding:60px 80px;
  display:grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap:40px;
}

.footer-column h3 {
  font-size:18px;
  font-weight:700;
  margin-bottom:15px;
  color:#fff;
}

.footer-column ul { list-style:none; padding:0; }
.footer-column ul li { margin-bottom:10px; }

.footer-column ul li a {
  text-decoration:none;
  color:#ffeaea;
  font-size:15px;
  transition:color 0.3s;
}

.footer-column ul li a:hover { color:#ffffff; }

.footer-contact p {
  font-size:15px;
  line-height:1.6;
  color:#ffeaea;
}

.footer-social {
  display:flex;
  gap:10px;
  margin-top:10px;
}

.footer-social a img {
  width:28px;
  height:28px;
  border-radius:6px;
  object-fit:cover;
  transition:transform 0.3s, opacity 0.3s;
}

.footer-social a img:hover {
  transform:scale(1.1);
  opacity:0.8;
}

.footer-bottom {
  text-align:center;
  padding:20px;
  background:#ffffff;
  color:#555;
  font-size:15px;
  box-shadow:0 -2px 8px rgba(0,0,0,0.05);
}

/* ===== Responsive ===== */
@media (max-width:900px){
  header { padding:15px 30px; height:auto; }
  .hero { padding:140px 30px 80px; }
  .hero-text h1 { font-size:38px; text-align:center; }
  .hero-text p { text-align:center; }
  .hero-content { flex-direction:column; gap:40px; }
  nav ul { display:none; }
}
</style>
</head>
<body>

<header>
  <div class="logo">
    <img src="AmbuFinder_LOGO.png" alt="AmbuFinder Logo">
    AmbuFinder
  </div>
  <nav>
    <ul>
      <li><a href="index.html">Home</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="services.php">Services</a></li>
      <li><a href="userlogin.php">Login</a></li>
      <li><a href="register.php">Sign Up</a></li>
      <li><a href="#" class="download-btn">Download App</a></li>
    </ul>
  </nav>
</header>

<!-- ===== Hero Section with Video ===== -->
<section class="hero">
  <div class="hero-content">
    <div class="hero-text">
      <h1>Fast. Reliable. Life-Saving.<br>AmbuFinder</h1>
      <p>Your trusted emergency ambulance service — helping you reach medical aid in minutes, anywhere.</p>
    </div>

    <!-- Video replaces the old image -->
    <div class="hero-video">
      <video controls autoplay loop playsinline>
        <source src="ambulance video.mp4" type="video/mp4">
        Your browser does not support the video tag.
      </video>
    </div>
  </div>
</section>

<!-- ===== Footer Section ===== -->
<section class="footer-section">
  <div class="footer-column">
    <h3>About Us</h3>
    <ul>
      <li><a href="about/our_story.php">Our Story</a></li>
      <li><a href="about/how_we_operate.php">Where We Operate</a></li>
    </ul>
  </div>

  <div class="footer-column">
    <h3>Services</h3>
    <ul>
      <li><a href="#">Emergency Ambulance</a></li>
      <li><a href="#">Patient Transport</a></li>
      <li><a href="#">On-demand Booking</a></li>
    </ul>
  </div>

  <div class="footer-column">
    <h3>Support</h3>
    <ul>
      <li><a href="#">FAQs</a></li>
      <li><a href="#">Help Center</a></li>
    </ul>
  </div>

  <div class="footer-column footer-contact">
    <h3>Contact Us</h3>
    <p><strong>Head Office</strong><br>
    JSL Solutions Ltd.<br>
    Chittagong, Bangladesh</p>
    <p>Contact: 09610056789<br>
    Hotline: 16633<br>
    Email: support@ambufinder.com</p>

    <h3>Follow Us</h3>
    <div class="footer-social">
      <a href="#"><img src="facebook.png" alt="Facebook"></a>
      <a href="#"><img src="insta.jpg" alt="Instagram"></a>
      <a href="#"><img src="linkdln.png" alt="LinkedIn"></a>
    </div>
  </div>
</section>

<footer class="footer-bottom">
  © 2025 AmbuFinder | Emergency Ambulance Service
</footer>

<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>
