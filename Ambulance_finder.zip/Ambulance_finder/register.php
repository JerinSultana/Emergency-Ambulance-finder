<?php
session_start();
require 'includes/db_connect.php';

$err = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'] ?? 'user';
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!$name || !$phone || !$email || !$password) {
        $err = "Please fill all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = "Invalid email address.";
    } elseif (!preg_match('/^[0-9]{11}$/', $phone)) {
        $err = "Phone number must be 11 digits.";
    } elseif (strlen($password) < 8) {
        $err = "Password must be at least 8 characters long.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        if ($role === 'driver') {
            // Check if driver email exists
            $stmt = mysqli_prepare($conn, "SELECT id FROM drivers WHERE email=?");
            mysqli_stmt_bind_param($stmt, 's', $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);

            if (mysqli_stmt_num_rows($stmt) > 0) {
                $err = "Email already registered as driver.";
            } else {
                // Driver file uploads
                $nidFile = '';
                $licenseFile = '';
                if(isset($_FILES['nidFile']) && $_FILES['nidFile']['error']==0){
                    $nidFile = time().'_'.basename($_FILES['nidFile']['name']);
                    move_uploaded_file($_FILES['nidFile']['tmp_name'], 'uploads/nid/'.$nidFile);
                }
                if(isset($_FILES['licenseFile']) && $_FILES['licenseFile']['error']==0){
                    $licenseFile = time().'_'.basename($_FILES['licenseFile']['name']);
                    move_uploaded_file($_FILES['licenseFile']['tmp_name'], 'uploads/licenses/'.$licenseFile);
                }

                $stmt = mysqli_prepare($conn, "INSERT INTO drivers (name, phone, email, password, nid_file, license_file, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())");
                mysqli_stmt_bind_param($stmt, 'ssssss', $name, $phone, $email, $hash, $nidFile, $licenseFile);

                if(mysqli_stmt_execute($stmt)){
                    $_SESSION['driver_id'] = mysqli_insert_id($conn);
                    $_SESSION['driver_name'] = $name;
                    header('Location: index.php');
                    exit;
                } else {
                    $err = "Driver registration failed: " . mysqli_error($conn);
                }
            }

            mysqli_stmt_close($stmt);

        } else { // role = user
            // Check if user email exists
            $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email=?");
            mysqli_stmt_bind_param($stmt, 's', $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);

            if (mysqli_stmt_num_rows($stmt) > 0) {
                $err = "Email already registered.";
            } else {
                $stmt = mysqli_prepare($conn, "INSERT INTO users (name, phone, email, password, created_at) VALUES (?, ?, ?, ?, NOW())");
                mysqli_stmt_bind_param($stmt, 'ssss', $name, $phone, $email, $hash);

                if(mysqli_stmt_execute($stmt)){
                    $_SESSION['user_id'] = mysqli_insert_id($conn);
                    $_SESSION['user_name'] = $name;
                    header('Location: index.php');
                    exit;
                } else {
                    $err = "User registration failed: " . mysqli_error($conn);
                }
            }

            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>AmbuFinder — Signup</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body {
  font-family: 'Poppins', sans-serif;
  background: #fff;
  margin:0;
  padding:30px;
  color:#333;
}

/* Heading box */
.heading-box {
  background:#fff;
  padding:30px 25px;
  border-radius:15px;
  max-width:450px;
  margin:0 auto 60px auto;
  text-align:center;
  box-shadow:0 10px 30px rgba(0,0,0,0.15);
  border-top:5px solid #dc3545;
}
.heading-box h2 {
  color:#dc3545;
  font-size:34px;
  font-weight:700;
  margin:0;
}

/* Cards */
.container {
  display:flex;
  justify-content:center;
  align-items:center;
  gap:30px;
  flex-wrap:wrap;
  margin-bottom:40px;
}
.card-option {
  background:#fff;
  width:250px;
  height:150px;
  border-radius:15px;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  font-weight:600;
  font-size:20px;
  color:#dc3545;
  box-shadow:0 8px 25px rgba(0,0,0,0.15);
  cursor:pointer;
  text-align:center;
  transition: transform 0.3s, box-shadow 0.3s, background 0.3s;
}
.card-option:hover {
  transform: translateY(-10px);
  box-shadow: 0 12px 35px rgba(0,0,0,0.2);
  background:#ffe0ee;
}

/* Popup */
.popup {
  display:none;
  position:fixed;
  top:0; left:0;
  width:100%; height:100%;
  background: rgba(0,0,0,0.5);
  justify-content:center;
  align-items:center;
}
.popup-content {
  background:#fff;
  padding:30px;
  border-radius:15px;
  max-width:450px;
  width:100%;
  position:relative;
  box-shadow:0 8px 30px rgba(0,0,0,0.2);
  transform: translateY(-50px);
  opacity:0;
  transition: all 0.3s ease;
}
.popup.show .popup-content {
  transform: translateY(0);
  opacity:1;
}
h2#popupTitle {
  color:#dc3545;
  font-size:28px;
  font-weight:700;
  text-align:center;
  margin-bottom:25px;
}
.close-btn {
  position:absolute;
  top:10px;
  right:15px;
  font-size:22px;
  color:#dc3545;
  cursor:pointer;
  font-weight:bold;
}

input, label {width:100%; display:block;}
input {
  padding:12px;
  margin:6px 0 12px 0;
  border-radius:10px;
  border:1px solid #ffd6e5;
}
input:focus {outline:none; border-color:#dc3545; box-shadow:0 0 5px #f8c1c3;}
input[type="file"] {
  border:2px dashed #dc3545;
  padding:12px;
  border-radius:10px;
  cursor:pointer;
  background:#fff0f5;
  color:#dc3545;
  font-weight:600;
  margin-bottom:15px;
  transition:0.3s;
}
input[type="file"]:hover {background:#dc3545; color:#fff;}
button {
  background:#dc3545;
  color:#fff;
  padding:12px;
  width:100%;
  border:none;
  border-radius:10px;
  cursor:pointer;
  font-weight:600;
  font-size:16px;
  margin-top:10px;
}
button:hover {background:#b71c1c;}

.error {color:#b00020; margin-bottom:10px; text-align:center;}
.success {color:green; margin-bottom:10px; text-align:center;}
.login-link {text-align:center; margin-top:15px;}
.login-link a {color:#dc3545; text-decoration:none; font-weight:600;}
.login-link a:hover {text-decoration:underline;}
</style>
</head>
<body>

<div class="heading-box">
    <h2>Create Account</h2>
</div>

<div class="container">
    <div class="card-option" onclick="openPopup('user')">User</div>
    <div class="card-option" onclick="openPopup('driver')">Ambulance Driver</div>
</div>

<!-- Popup -->
<div id="popup" class="popup">
    <div class="popup-content">
        <span class="close-btn" onclick="closePopup()">&times;</span>
        <h2 id="popupTitle">Register</h2>
        <?php if($err) echo "<div class='error'>$err</div>"; ?>
        <?php if($success) echo "<div class='success'>$success</div>"; ?>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="role" id="roleField">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="text" name="phone" placeholder="Phone Number (11 digits)" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password (min 8 chars)" required>

            <!-- User NID -->
            <div id="nidFieldWrapper" style="display:none;">
                <label>Upload your NID</label>
                <input type="file" name="nidFile" accept="image/*,application/pdf">
            </div>

            <!-- Driver NID -->
            <div id="driverNidWrapper" style="display:none;">
                <label>Upload your NID</label>
                <input type="file" name="nidFile" accept="image/*,application/pdf">
            </div>

            <!-- Driver License -->
            <div id="licenseFieldWrapper" style="display:none;">
                <label>Upload Driving License</label>
                <input type="file" name="licenseFile" accept="image/*,application/pdf">
            </div>

            <button type="submit">Sign Up</button>
        </form>
        <div class="login-link">
            <p>Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>
</div>

<script>
function openPopup(role){
    const popup=document.getElementById('popup');
    popup.style.display='flex';
    popup.classList.add('show');
    document.getElementById('roleField').value = role;
    document.getElementById('popupTitle').innerText = 'Register as ' + (role.charAt(0).toUpperCase() + role.slice(1));

    document.getElementById('nidFieldWrapper').style.display = (role==='user') ? 'block' : 'none';
    document.getElementById('driverNidWrapper').style.display = (role==='driver') ? 'block' : 'none';
    document.getElementById('licenseFieldWrapper').style.display = (role==='driver') ? 'block' : 'none';
}

function closePopup(){
    const popup=document.getElementById('popup');
    popup.style.display='none';
    popup.classList.remove('show');
}
</script>

</body>
</html>
