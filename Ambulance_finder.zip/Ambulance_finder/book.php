<?php
session_start();
include 'includes/db_connect.php';

// Ensure user is logged in
if(!isset($_SESSION['user_id'])){
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambulance type colors
$colors = [
    'Normal Ambulance'=>'#28a745', // green
    'Oxygen Ambulance'=>'#007bff', // blue
    'ICU Ambulance'=>'#6f42c1',    // purple
];

// Demo ambulances
$demo_ambulances = [
    ['id'=>1,'type'=>'Normal Ambulance','name'=>'GEC Normal Ambulance','phone'=>'01711111111','status'=>'available'],
    ['id'=>2,'type'=>'Oxygen Ambulance','name'=>'GEC Oxygen Ambulance','phone'=>'01722222222','status'=>'available'],
    ['id'=>3,'type'=>'ICU Ambulance','name'=>'GEC ICU Ambulance','phone'=>'01833333333','status'=>'available'],
];

// Update ambulance status based on pending bookings
foreach($demo_ambulances as &$amb){
    $id = $amb['id'];
    $check = mysqli_query($conn,"SELECT * FROM bookings WHERE ambulance_id='$id' AND status='Pending'");
    $amb['status'] = mysqli_num_rows($check) > 0 ? 'Busy' : 'Available';
}

// Handle booking submission
if(isset($_POST['book_now'])){
    $ambulance_id = $_POST['ambulance_id'];
    $pickup = $_POST['pickup'];
    $drop_location = $_POST['drop_location'];
    $cost = $_POST['cost'];
    $booking_time = date('Y-m-d H:i:s');

    $insert_sql = "INSERT INTO bookings (user_id, ambulance_id, pickup, drop_location, cost, booking_time, status)
                   VALUES ('$user_id', '$ambulance_id', '$pickup', '$drop_location', '$cost', '$booking_time', 'Pending')";

    if(mysqli_query($conn, $insert_sql)){
        $success = "Ambulance booked successfully!";

        // -----------------------------
        // Send email notification
        // -----------------------------
        $user_query = mysqli_query($conn, "SELECT email FROM users WHERE id='$user_id'");
        $user_data = mysqli_fetch_assoc($user_query);
        $user_email = $user_data['email'] ?? '';

        $subject = "Ambulance Booking Confirmation";
        $message = "
        Hello,
        Your ambulance booking has been placed successfully!
        📍 Pickup: $pickup
        🚑 Drop: $drop_location
        💰 Cost: $cost BDT
        ⏰ Time: $booking_time

        We’ll notify you when the ambulance is on the way.
        - AmbuFinder Team
        ";
        $headers = "From: ambufinder@example.com";

        @mail($user_email, $subject, $message, $headers);
    } else {
        $error = "Error: ".mysqli_error($conn);
    }
}

// Filter demo ambulances based on typed pickup location
$available_ambulances = [];
if(isset($_POST['search_location'])){
    $typed_name = strtolower(trim($_POST['pickup']));
    foreach($demo_ambulances as $amb){
        if(strpos(strtolower($amb['name']), $typed_name)!==false){
            $available_ambulances[] = $amb;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Book Ambulance</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { font-family:'Poppins',sans-serif; background:#f1f3f6; margin:0; }
.container { max-width:600px; margin:30px auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 6px 15px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#dc3545; margin-bottom:20px; }
input[type=text], select { width:100%; padding:12px; margin:10px 0; border-radius:8px; border:1px solid #ccc; }
button { width:100%; padding:12px; background:#dc3545; color:#fff; border:none; border-radius:8px; font-size:16px; cursor:pointer; margin-top:10px; }
button:hover { background:#c82333; }
.success { color:green; text-align:center; margin-bottom:10px; }
.error { color:red; text-align:center; margin-bottom:10px; }
.card { background:#f9f9f9; padding:15px; border-radius:10px; margin-bottom:15px; box-shadow:0 4px 8px rgba(0,0,0,0.05); }
.card h3 { margin:0; color:#dc3545; display:inline-block; margin-right:10px; }
.card img { vertical-align:middle; margin-right:10px; }
#suggestions { position:absolute; width:calc(100% - 50px); background:#fff; border:1px solid #ccc; border-radius:6px; max-height:150px; overflow-y:auto; display:none; z-index:1000; }
#suggestions div { padding:8px; cursor:pointer; }
#suggestions div:hover { background:#dc3545; color:#fff; }
</style>
</head>
<body>

<div class="container">
    <h2>Book Ambulance 🚑</h2>

    <?php if(isset($success)) echo "<div class='success'>$success</div>"; ?>
    <?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>

    <!-- Step 1: Search Pickup Location -->
    <form method="POST" style="position:relative;">
        <label>Pickup Location</label>
        <input type="text" name="pickup" id="pickupInput" placeholder="Type location (e.g., GEC)" required onkeyup="fetchSuggestions(this.value)">
        <div id="suggestions"></div>
        <button type="submit" name="search_location">Search Ambulances</button>
    </form>

    <?php if(!empty($available_ambulances)): ?>
        <h3>Available Ambulances Near "<?php echo htmlspecialchars($_POST['pickup']); ?>"</h3>
        <form method="POST">
            <input type="hidden" name="pickup" value="<?php echo htmlspecialchars($_POST['pickup']); ?>">
            <label>Drop Location</label>
            <input type="text" name="drop_location" placeholder="Enter your drop location" required onchange="updateCost()">
            <input type="hidden" name="cost" id="cost" value="">

            <?php foreach($available_ambulances as $amb): ?>
                <div class="card">
                    <img src="images/<?php echo strtolower(str_replace(' ','_',$amb['type'])); ?>.png" width="50" alt="Ambulance">
                    <h3><?php echo $amb['name']; ?></h3>
                    <span style="background:<?php echo $colors[$amb['type']]; ?>;color:white;padding:3px 8px;border-radius:5px;"><?php echo $amb['type']; ?></span>
                    <p>Phone: <?php echo $amb['phone']; ?></p>
                    <p>Status: <?php echo ucfirst($amb['status']); ?></p>
                    <p>Estimated Cost: ৳<span class="display-cost">0</span></p>

                    <!-- Cost & ETA Bar -->
                    <?php $progress = rand(20,100); ?>
                    <div style="background:#eee;width:100%;border-radius:5px;margin:5px 0;">
                        <div style="width:<?php echo $progress; ?>%;background:#dc3545;height:10px;border-radius:5px;"></div>
                    </div>

                    <input type="hidden" name="ambulance_id" value="<?php echo $amb['id']; ?>">
                    <button type="submit" name="book_now" <?php echo $amb['status']=='Busy' ? 'disabled' : ''; ?>>Book This Ambulance</button>

                    <!-- SOS Button -->
                    <button type="button" onclick="showSOSModal()" style="background:#ffc107;color:#000;margin-top:5px;">SOS</button>
                </div>
            <?php endforeach; ?>
        </form>
    <?php elseif(isset($_POST['search_location'])): ?>
        <p style="color:red; text-align:center;">No ambulances found for "<?php echo htmlspecialchars($_POST['pickup']); ?>"</p>
    <?php endif; ?>

</div>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places"></script>
<script>
// Fetch suggestions
function fetchSuggestions(query){
    let suggestionsDiv = document.getElementById('suggestions');
    if(query.length === 0){
        suggestionsDiv.style.display = 'none';
        return;
    }

    const demoNames = <?php echo json_encode(array_column($demo_ambulances, 'name')); ?>;
    let matches = demoNames.filter(name => name.toLowerCase().includes(query.toLowerCase()));

    suggestionsDiv.innerHTML = '';
    if(matches.length > 0){
        matches.forEach(name => {
            let div = document.createElement('div');
            div.innerText = name;
            div.onclick = () => selectSuggestion(name);
            suggestionsDiv.appendChild(div);
        });
    } else {
        suggestionsDiv.innerHTML = '<div>No matching locations found</div>';
    }
    suggestionsDiv.style.display = 'block';
}

function selectSuggestion(name){
    document.getElementById('pickupInput').value = name;
    document.getElementById('suggestions').style.display = 'none';
}

// Distance-based cost calculation
function calculateCost(pickup, drop, callback){
    const service = new google.maps.DistanceMatrixService();
    service.getDistanceMatrix(
        { origins:[pickup], destinations:[drop], travelMode: google.maps.TravelMode.DRIVING },
        function(response, status){
            if(status==='OK'){
                const distanceValue = response.rows[0].elements[0].distance.value;
                const distanceKm = distanceValue/1000;
                const costPerKm = 100;
                const cost = Math.round(distanceKm*costPerKm);
                document.getElementById('cost').value = cost;
                document.querySelectorAll('.display-cost').forEach(el=>el.innerText=cost);
                callback(cost);
            } else {
                alert("Unable to calculate distance!");
            }
        }
    );
}

function updateCost(){
    const pickup = document.querySelector('input[name="pickup"]').value;
    const drop = document.querySelector('input[name="drop_location"]').value;
    if(pickup && drop){
        calculateCost(pickup, drop, c=>console.log("Cost calculated:", c));
    }
}

// SOS modal
function showSOSModal(){
    alert('Sending SOS...');
}
</script>
</body>
</html>
