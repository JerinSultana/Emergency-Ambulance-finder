<?php
session_start();
include 'includes/db_connect.php';

// Ensure user is logged in
if(!isset($_SESSION['user_id'])){
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle AJAX cancel request
if(isset($_POST['cancel_id'])){
    $cancel_id = intval($_POST['cancel_id']);
    $update_sql = "UPDATE bookings SET status='Cancelled' WHERE id='$cancel_id' AND user_id='$user_id' AND status='Pending'";
    if(mysqli_query($conn, $update_sql)){
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
    }
    exit;
}

// Handle AJAX feedback submission
if(isset($_POST['feedback_booking_id'])){
    $booking_id = intval($_POST['feedback_booking_id']);
    $rating = intval($_POST['rating']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    $insert_sql = "INSERT INTO feedback (booking_id, user_id, rating, comment) VALUES ('$booking_id','$user_id','$rating','$comment')";
    if(mysqli_query($conn, $insert_sql)){
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false,'error'=>mysqli_error($conn)]);
    }
    exit;
}

// Booking history filtering
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$from_date = isset($_GET['from_date']) ? $_GET['from_date'] : '';
$to_date = isset($_GET['to_date']) ? $_GET['to_date'] : '';

// Build filtered query
$sql = "SELECT * FROM bookings WHERE user_id='$user_id'";

if($status_filter){
    $sql .= " AND status='$status_filter'";
}

if($from_date){
    $sql .= " AND DATE(booking_time) >= '$from_date'";
}

if($to_date){
    $sql .= " AND DATE(booking_time) <= '$to_date'";
}

$sql .= " ORDER BY booking_time DESC";

$result = mysqli_query($conn, $sql);

// Status colors
$status_colors = [
    'Pending' => '#ffc107',
    'Completed' => 'green',
    'Cancelled' => 'red'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Bookings</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { font-family:'Poppins',sans-serif; background:#f1f3f6; margin:0; }
.container { max-width:950px; margin:50px auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 6px 15px rgba(0,0,0,0.1); }
h2 { text-align:center; color:#dc3545; margin-bottom:20px; }
table { width:100%; border-collapse:collapse; margin-top:20px; }
table th, table td { padding:12px; border-bottom:1px solid #ddd; text-align:center; }
table th { background:#dc3545; color:white; }
.status-badge { color:white; padding:4px 10px; border-radius:6px; font-weight:bold; }
button.cancel-btn, button.feedback-btn { padding:6px 12px; border:none; border-radius:6px; cursor:pointer; }
button.cancel-btn { background:#dc3545; color:#fff; }
button.cancel-btn:hover { background:#c82333; }
button.feedback-btn { background:#007bff; color:#fff; }
button.feedback-btn:hover { background:#0069d9; }
.filter-form { margin-bottom:20px; display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap; }
.filter-form input, .filter-form select, .filter-form button { padding:8px; border-radius:6px; border:1px solid #ccc; }
.modal { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); justify-content:center; align-items:center; }
.modal-content { background:#fff; padding:20px; border-radius:12px; max-width:400px; width:90%; text-align:center; }
.star { font-size:30px; cursor:pointer; color:#ccc; }
.star.selected { color:#ffc107; }
textarea { width:100%; padding:8px; margin-top:10px; border-radius:6px; border:1px solid #ccc; resize:none; }
.modal button { margin-top:12px; padding:8px 14px; border:none; border-radius:6px; cursor:pointer; background:#28a745; color:#fff; }
.modal button:hover { background:#218838; }
@media(max-width:768px){
    table th, table td { padding:8px; font-size:14px; }
    .filter-form { flex-direction:column; align-items:flex-start; }
}
</style>
</head>
<body>

<div class="container">
    <h2>My Bookings</h2>

    <!-- Booking filter form -->
    <form method="GET" class="filter-form">
        <select name="status">
            <option value="">All Statuses</option>
            <option value="Pending" <?php if($status_filter=='Pending') echo 'selected'; ?>>Pending</option>
            <option value="Completed" <?php if($status_filter=='Completed') echo 'selected'; ?>>Completed</option>
            <option value="Cancelled" <?php if($status_filter=='Cancelled') echo 'selected'; ?>>Cancelled</option>
        </select>
        <input type="date" name="from_date" value="<?php echo htmlspecialchars($from_date); ?>">
        <input type="date" name="to_date" value="<?php echo htmlspecialchars($to_date); ?>">
        <button type="submit">Filter</button>
    </form>

    <?php if(mysqli_num_rows($result) > 0) { ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Pickup</th>
                <th>Drop Location</th>
                <th>Status</th>
                <th>Booking Time</th>
                <th>Action</th>
            </tr>
            <?php while($row = mysqli_fetch_assoc($result)) { ?>
            <tr id="booking-<?php echo $row['id']; ?>">
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['pickup']); ?></td>
                <td><?php echo htmlspecialchars($row['drop_location']); ?></td>
                <td>
                    <span class="status-badge" style="background:<?php echo $status_colors[$row['status']]; ?>;"><?php echo $row['status']; ?></span>
                </td>
                <td><?php echo $row['booking_time']; ?></td>
                <td>
                    <?php if($row['status']=='Pending'){ ?>
                        <button class="cancel-btn" onclick="cancelBooking(<?php echo $row['id']; ?>)">Cancel</button>
                    <?php } elseif($row['status']=='Completed'){ ?>
                        <button class="feedback-btn" onclick="openFeedbackModal(<?php echo $row['id']; ?>)">Give Feedback</button>
                    <?php } else { echo '-'; } ?>
                </td>
            </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p style="text-align:center; color:#555;">No bookings found.</p>
    <?php } ?>
</div>

<!-- Feedback Modal -->
<div class="modal" id="feedbackModal">
    <div class="modal-content">
        <h3>Give Your Feedback</h3>
        <div id="stars">
            <span class="star" data-value="1">&#9733;</span>
            <span class="star" data-value="2">&#9733;</span>
            <span class="star" data-value="3">&#9733;</span>
            <span class="star" data-value="4">&#9733;</span>
            <span class="star" data-value="5">&#9733;</span>
        </div>
        <textarea id="feedbackComment" placeholder="Write your comment (optional)"></textarea>
        <button onclick="submitFeedback()">Submit</button>
        <button onclick="closeFeedbackModal()" style="background:#dc3545;margin-top:5px;">Cancel</button>
    </div>
</div>

<script>
// AJAX cancel booking
function cancelBooking(id){
    if(!confirm('Are you sure you want to cancel this booking?')) return;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function(){
        if(this.status==200){
            const response = JSON.parse(this.responseText);
            if(response.success){
                const row = document.getElementById('booking-' + id);
                row.querySelector('.status-badge').innerText = 'Cancelled';
                row.querySelector('.status-badge').style.background = 'red';
                row.querySelector('button.cancel-btn').remove();
                alert('Booking cancelled successfully!');
            } else {
                alert('Error cancelling booking!');
            }
        }
    };
    xhr.send('cancel_id=' + id);
}

// Feedback system
let selectedBookingId = 0;
let selectedRating = 0;
const stars = document.querySelectorAll('.star');

function openFeedbackModal(bookingId){
    selectedBookingId = bookingId;
    document.getElementById('feedbackModal').style.display = 'flex';
    selectedRating = 0;
    stars.forEach(s => s.classList.remove('selected'));
    document.getElementById('feedbackComment').value = '';
}

function closeFeedbackModal(){
    document.getElementById('feedbackModal').style.display = 'none';
}

stars.forEach(star=>{
    star.addEventListener('mouseover', ()=>{
        let val = parseInt(star.getAttribute('data-value'));
        highlightStars(val);
    });
    star.addEventListener('mouseout', ()=>{
        highlightStars(selectedRating);
    });
    star.addEventListener('click', ()=>{
        selectedRating = parseInt(star.getAttribute('data-value'));
        highlightStars(selectedRating);
    });
});

function highlightStars(rating){
    stars.forEach(s=>{
        let val = parseInt(s.getAttribute('data-value'));
        if(val <= rating) s.classList.add('selected');
        else s.classList.remove('selected');
    });
}

function submitFeedback(){
    const comment = document.getElementById('feedbackComment').value;
    if(selectedRating===0){
        alert('Please select a rating!');
        return;
    }
    const xhr = new XMLHttpRequest();
    xhr.open('POST','',true);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.onload = function(){
        if(this.status==200){
            const res = JSON.parse(this.responseText);
            if(res.success){
                alert('Feedback submitted successfully!');
                closeFeedbackModal();
            } else alert('Error submitting feedback!');
        }
    };
    xhr.send('feedback_booking_id='+selectedBookingId+'&rating='+selectedRating+'&comment='+encodeURIComponent(comment));
}
</script>

</body>
</html>
