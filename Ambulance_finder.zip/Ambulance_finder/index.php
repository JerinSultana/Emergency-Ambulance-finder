<?php
session_start();
include 'includes/db_connect.php';

if(!isset($_SESSION['user_id'])){
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Example ambulance data with images
$alternative_options = [
    [
        'type' => 'Oxygen Ambulance',
        'name' => 'Sheba oxygen Ambulance',
        'phone' => '017XXXXXXXX',
        'cost' => 350,
        'eta' => '12 min',
        'distance' => '3.4 km',
        'badge' => 'Oxygen Support',
        'icon' => '',
        'color' => '#17a2b8',
        'lat' => 22.343,
        'lng' => 91.802,
        'status' => 'Available',
        'image' => 'oxygen ambu.png'
    ],
    [
        'type' => 'ICU Ambulance',
        'name' => 'United Critical Care',
        'phone' => '018XXXXXXXX',
        'cost' => 450,
        'eta' => '9 min',
        'distance' => '2.7 km',
        'badge' => 'ICU Facility',
        'icon' => '',
        'color' => '#6f42c1',
        'lat' => 22.356,
        'lng' => 91.823,
        'status' => 'Available',
        'image' => 'icu ambu.png'
    ],
    [
        'type' => 'Normal Ambulance',
        'name' => 'Shushastho Ambulance',
        'phone' => '019XXXXXXXX',
        'cost' => 300,
        'eta' => '10 min',
        'distance' => '2.9 km',
        'badge' => 'Normal Ambulance',
        'icon' => '',
        'color' => '#007bff',
        'lat' => 22.334,
        'lng' => 91.811,
        'status' => 'Available',
        'image' => 'normal ambu.png'
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AmbuFinder 🚑 Emergency Ambulance</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { margin:0; font-family:'Poppins',sans-serif; background:#f1f3f6; }

/* Sidebar */
.sidebar { position: fixed; top:0; left:-240px; width:220px; height:100%; background:#fff; padding-top:20px; box-shadow:2px 0 10px rgba(0,0,0,0.1); border-radius:0 12px 12px 0; text-align:center; z-index:1000; transition: left 0.3s ease; }
.sidebar.active { left:0; }
.sidebar img { width:90px; height:90px; border-radius:50%; margin-bottom:12px; }
.sidebar h2 { color:#dc3545; margin-bottom:25px; font-weight:600; font-size:18px; }
.sidebar a { display:block; padding:12px; margin:8px 16px; color:#333; text-decoration:none; text-align:left; border-radius:8px; transition:all 0.3s; font-weight:500; }
.sidebar a:hover { background:#dc3545; color:#fff; }

/* Menu */
.menu-bar { position:fixed; top:15px; left:15px; font-size:28px; cursor:pointer; color:#dc3545; z-index:1100; background:#fff; padding:8px 12px; border-radius:8px; box-shadow:0 4px 10px rgba(0,0,0,0.15); }
.lang-toggle { position:fixed; top:15px; right:15px; font-size:15px; cursor:pointer; background:#dc3545; color:#fff; border:none; padding:8px 12px; border-radius:8px; box-shadow:0 4px 10px rgba(0,0,0,0.2); }
.sos-btn { position:fixed; bottom:20px; right:20px; background:#dc3545; color:#fff; padding:12px 16px; border:none; border-radius:50px; font-size:16px; cursor:pointer; box-shadow:0 4px 10px rgba(0,0,0,0.2); z-index:1200; }

.main-content { margin-left:0; padding:20px; transition: margin-left 0.3s ease; }
.main-content.shifted { margin-left:240px; }

.search-box { margin-bottom: 15px; text-align: center; position:relative; }
.search-box input { padding: 12px; border-radius: 8px; border: 1px solid #ccc; width: 70%; max-width: 600px; font-size: 16px; }
.search-box button { padding: 12px 20px; background: #dc3545; color: #fff; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; margin-left: 8px; }

.filters { display: flex; justify-content: center; gap: 12px; margin: 15px 0 25px 0; }
.filter-btn { padding: 10px 18px; border: none; border-radius: 8px; cursor: pointer; background: #eee; font-size: 15px; transition: all 0.3s; }
.filter-btn:hover { background: #dc3545; color:#fff; }

/* Card Styles */
.card { background:#fff; border-radius:15px; padding:15px; margin-bottom:20px; box-shadow:0 6px 15px rgba(0,0,0,0.08); display:flex; justify-content:space-between; align-items:center; position:relative; }
.card .info { flex:1; }
.card .icon { font-size:40px; margin-bottom:10px; }
.card .info h3 { margin:0; font-size:18px; font-weight:600; }
.card .info p { margin:3px 0; font-size:14px; }
.btn-call, .btn-book, .btn-chat { display:inline-block; padding:8px 16px; color:#fff; text-decoration:none; border-radius:8px; margin-top:8px; cursor:pointer; border:none; font-size:14px; font-weight:600; }
.btn-call { background:#28a745; }
.btn-book { background:#dc3545; margin-left:5px; }
.btn-chat { background:#007bff; margin-left:5px; }
.badge { position:absolute; top:10px; right:10px; background:#ffc107; padding:4px 8px; border-radius:6px; font-size:12px; }

/* Ambulance Image */
.ambulance-image img { width:200px; height:auto; border-radius:12px; margin-left:20px; box-shadow:0 4px 10px rgba(0,0,0,0.2); }

/* Why Choose Us */
.why-choose { background:#fff; border-radius:15px; padding:20px; box-shadow:0 6px 15px rgba(0,0,0,0.08); margin-top:20px; text-align:center; }
.why-choose h2 { color:#dc3545; margin-bottom:15px; }
.features-container { display:flex; justify-content:center; flex-wrap:wrap; gap:20px; margin-top:15px; }
.feature { opacity:0; transform: translateY(50px); background:#fff; border:2px solid #dc3545; padding:20px; border-radius:15px; font-weight:600; font-size:16px; width:200px; text-align:center; box-shadow:0 8px 15px rgba(0,0,0,0.1); transition: all 0.6s ease; cursor:default; }
.feature span { display:block; margin-top:10px; font-size:16px; font-weight:600; color:#dc3545; }
.feature:hover { transform: translateY(-5px); box-shadow:0 12px 20px rgba(0,0,0,0.2); }
.feature.show { opacity:1; transform: translateY(0); }

/* Testimonials */
.testimonials { background: #fff; margin: 30px 0; padding: 25px; border-radius: 15px; box-shadow: 0 6px 15px rgba(0,0,0,0.08); text-align: center; }
.testimonials h2 { color: #dc3545; margin-bottom: 20px; font-size: 22px; }
.testimonial-cards { display: flex; justify-content: center; flex-wrap: wrap; gap: 20px; }
.testimonial-card { background: #f8f9fa; color: #333; border-radius: 12px; padding: 18px; width: 260px; font-size: 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); transition: transform 0.3s ease, box-shadow 0.3s ease; }
.testimonial-card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.15); }

/* Chat Bubble & Popup */
#chatBubble { position:fixed; bottom:20px; right:20px; width:60px; height:60px; background:#007bff; border-radius:50%; display:flex; justify-content:center; align-items:center; cursor:pointer; color:#fff; font-size:28px; z-index:1500; box-shadow:0 4px 10px rgba(0,0,0,0.2); transition: transform 0.3s ease; }
#chatBubble:hover { transform: scale(1.1); }
#chatPopup { position:fixed; bottom:90px; right:20px; width:320px; max-height:400px; background:#fff; border-radius:15px; box-shadow:0 6px 20px rgba(0,0,0,0.25); display:none; flex-direction:column; overflow:hidden; z-index:1501; animation: slideIn 0.4s ease forwards; }
@keyframes slideIn { from { opacity:0; transform:translateY(30px);} to{opacity:1; transform:translateY(0);} }
#chatHeader { background:#007bff; color:#fff; padding:10px 15px; font-weight:600; display:flex; justify-content:space-between; align-items:center; font-size:16px; }
#chatHeader span { cursor:pointer; font-size:18px; }
#chatMessages { flex:1; padding:10px; overflow-y:auto; background:#f1f3f6; }
#chatMessages div { margin:5px 0; padding:6px 10px; border-radius:12px; max-width:80%; word-wrap: break-word; }
#chatMessages .userMsg { background:#007bff; color:#fff; text-align:right; margin-left:auto; }
#chatMessages .driverMsg { background:#e4e6eb; color:#333; text-align:left; margin-right:auto; }
.chatInput { display:flex; padding:10px; border-top:1px solid #ddd; }
.chatInput input { flex:1; padding:8px 10px; border-radius:8px; border:1px solid #ccc; }
.chatInput button { padding:8px 12px; background:#007bff; color:#fff; border:none; border-radius:8px; margin-left:5px; cursor:pointer; }

footer { text-align:center; padding:15px; margin-top:20px; font-size:14px; color:#555; }

@media(max-width:768px){ 
    .main-content.shifted { margin-left:0; } 
    .testimonial-card { width:90%; margin-bottom:15px; }
    .card { flex-direction: column; align-items:flex-start; }
    .ambulance-image img { margin-left:0; margin-top:12px; width:100%; }
}
</style>
</head>
<body>

<div class="menu-bar" onclick="toggleSidebar()">☰</div>
<button class="lang-toggle" onclick="toggleLanguage()">বাংলা</button>
<button class="sos-btn" onclick="sosCall()">SOS 🚨</button>

<div class="sidebar" id="sidebar">
    <img src="user.png" alt="User">
    <h2 id="title">AmbuFinder</h2>
    <a href="index.php" id="home">Home</a>
    <a href="book.php" id="book">Book Ambulance</a>
    <a href="my_bookings.php" id="myBookings">My Bookings</a>
    <a href="payments.php" id="payments">Payments</a>
</div>

<div class="main-content" id="main-content">
    <h1 id="welcome">Welcome to AmbuFinder 🚑</h1>
    <p id="desc">Search, filter and book ambulances easily.</p>

    <div class="search-box">
        <input type="text" id="locationInput" placeholder="Enter ambulance name">
        <button id="searchBtn" onclick="searchLocation()">Search</button>
    </div>

    <div class="filters">
        <button class="filter-btn" id="normalBtn" onclick="filterType('Normal Ambulance')">Normal</button>
        <button class="filter-btn" id="oxygenBtn" onclick="filterType('Oxygen Ambulance')">Oxygen</button>
        <button class="filter-btn" id="icuBtn" onclick="filterType('ICU Ambulance')">ICU</button>
        <button class="filter-btn" id="showAllBtn" onclick="filterType('All')">Show All</button>
    </div>

    <h2 style="color:#dc3545;" id="availableText">Available Ambulances 🚑</h2>

    <?php foreach($alternative_options as $alt): ?>
    <div class="card" data-type="<?= $alt['type'] ?>" data-lat="<?= $alt['lat'] ?>" data-lng="<?= $alt['lng'] ?>" data-status="<?= $alt['status'] ?>" style="border-left:5px solid <?= $alt['color'] ?>">
        
        <div class="info">
            <div class="icon"><?= $alt['icon'] ?></div>
            <h3><?= $alt['name'] ?></h3>
            <p>Type: <?= $alt['type'] ?></p>
            <p>Phone: <?= $alt['phone'] ?></p>
            <p>Estimated Cost: ৳<?= $alt['cost'] ?></p>
            <p class='eta'>ETA: <?= $alt['eta'] ?> | Distance: <?= $alt['distance'] ?></p>
            <a class='btn-call' href='tel:<?= $alt['phone'] ?>'>Call Now</a>
            <button class='btn-book'>Book Now</button>
            <button class='btn-chat' onclick="openChat('<?= $alt['name'] ?>')">Chat Now</button>
        </div>

        <div class="ambulance-image">
            <img src="<?= $alt['image'] ?>" alt="<?= $alt['type'] ?>" />
        </div>

        <div class='badge'><?= $alt['status'] ?> 🚑</div>
    </div>
    <?php endforeach; ?>

    <!-- Why Choose Us -->
    <div class="why-choose">
        <h2>Why Choose Us?</h2>
        <div class="features-container">
            <div class="feature"><span>Fast Response Time</span></div>
            <div class="feature"><span>Well-Equipped Ambulances</span></div>
            <div class="feature"><span>Verified Drivers</span></div>
            <div class="feature"><span>Transparent Pricing</span></div>
            <div class="feature"><span>24/7 Availability</span></div>
        </div>
    </div>

    <!-- Testimonials -->
    <div class="testimonials">
        <h2>What Our Users Say</h2>
        <div class="testimonial-cards">
            <div class="testimonial-card">
                "AmbuFinder helped me quickly find the nearest ambulance during an emergency. Highly recommend!"
            </div>
            <div class="testimonial-card">
                "I appreciated how simple and clear the app was during an emergency."
            </div>
            <div class="testimonial-card">
                "Reliable service make AmbuFinder my go-to app in emergencies."
            </div>
        </div>
    </div>

    <footer id="footer">📞 Emergency Hotline: 999 | Powered by AmbuFinder</footer>
</div>

<!-- Chat Bubble & Popup -->
<div id="chatBubble" onclick="openChatPopup()">💬</div>
<div id="chatPopup">
    <div id="chatHeader">
        <span id="chatDriver">Driver Name</span>
        <span onclick="closeChatPopup()">✖</span>
    </div>
    <div id="chatMessages"></div>
    <div class="chatInput">
        <input type="text" id="chatInput" placeholder="Type a message">
        <button onclick="sendMessage()">Send</button>
    </div>
</div>

<script>
let currentLang = 'en';
function toggleSidebar(){
    document.getElementById("sidebar").classList.toggle("active");
    document.getElementById("main-content").classList.toggle("shifted");
}
function toggleLanguage(){
    const langBtn = document.querySelector(".lang-toggle");
    const text = {
        en: { title:"AmbuFinder", home:"Home", book:"Book Ambulance", myBookings:"My Bookings", payments:"Payments", welcome:"Welcome to AmbuFinder 🚑", desc:"Search, filter and book ambulances easily.", searchBtn:"Search", available:"Available Ambulances 🚑" },
        bn: { title:"অ্যাম্বুলেন্স ফাইন্ডার", home:"হোম", book:"অ্যাম্বুলেন্স বুক করুন", myBookings:"আমার বুকিং", payments:"পেমেন্ট", welcome:"অ্যাম্বুলেন্স ফাইন্ডারে স্বাগতম 🚑", desc:"সহজে অ্যাম্বুলেন্স সার্চ, ফিল্টার ও বুক করুন", searchBtn:"সার্চ", available:"উপলব্ধ অ্যাম্বুলেন্স 🚑" }
    };
    currentLang = currentLang==='en'?'bn':'en';
    const t = text[currentLang];
    document.getElementById("title").innerText=t.title;
    document.getElementById("home").innerText=t.home;
    document.getElementById("book").innerText=t.book;
    document.getElementById("myBookings").innerText=t.myBookings;
    document.getElementById("payments").innerText=t.payments;
    document.getElementById("welcome").innerText=t.welcome;
    document.getElementById("desc").innerText=t.desc;
    document.getElementById("searchBtn").innerText=t.searchBtn;
    document.getElementById("availableText").innerText=t.available;
}

function filterType(type){
    const cards = document.querySelectorAll('.card');
    cards.forEach(card=>{
        if(type==='All' || card.dataset.type===type){
            card.style.display='flex';
        }else{
            card.style.display='none';
        }
    });
}

function openChat(driver){
    document.getElementById('chatDriver').innerText=driver;
    openChatPopup();
}

function openChatPopup(){ document.getElementById('chatPopup').style.display='flex'; }
function closeChatPopup(){ document.getElementById('chatPopup').style.display='none'; }

function sendMessage(){
    const input = document.getElementById('chatInput');
    const msg = input.value.trim();
    if(msg!==''){
        const msgDiv=document.createElement('div');
        msgDiv.className='userMsg'; msgDiv.innerText=msg;
        document.getElementById('chatMessages').appendChild(msgDiv);
        input.value=''; 
        document.getElementById('chatMessages').scrollTop=document.getElementById('chatMessages').scrollHeight;
    }
}

document.addEventListener('DOMContentLoaded', ()=>{
    const features=document.querySelectorAll('.feature');
    features.forEach((f,i)=>setTimeout(()=>{f.classList.add('show');},i*150));
});
</script>

</body>
</html>
