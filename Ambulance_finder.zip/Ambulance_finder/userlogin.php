<?php
// ---------------- SECURE SESSION START ---------------- //
$cookieParams = session_get_cookie_params();
session_set_cookie_params([
  'lifetime' => $cookieParams['lifetime'],
  'path' => $cookieParams['path'],
  'domain' => $cookieParams['domain'],
  'secure' => false, // change to true on HTTPS
  'httponly' => true,
  'samesite' => 'Lax'
]);
session_start();

require 'includes/db_connect.php';

$err = '';
$success = '';

// ---------------- SECURITY FEATURES ---------------- //
// Rate Limiting
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt_time'] = time();
}
if (time() - $_SESSION['last_attempt_time'] > 600) {
    $_SESSION['login_attempts'] = 0;
}

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ---------------- DEMO ACCOUNT ---------------- //
$demo_name = "Demo User";
$demo_email = "demo@example.com";
$demo_phone = "01711112222";
$demo_password_plain = "password123";
$demo_role = "user";

$stmt_check = mysqli_prepare($conn, "SELECT id FROM users WHERE email=? LIMIT 1");
mysqli_stmt_bind_param($stmt_check, 's', $demo_email);
mysqli_stmt_execute($stmt_check);
mysqli_stmt_store_result($stmt_check);

if (mysqli_stmt_num_rows($stmt_check) === 0) {
    $stmt_insert = mysqli_prepare($conn, "INSERT INTO users (name, phone, email, password, role) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt_insert, 'sssss', $demo_name, $demo_phone, $demo_email, $demo_password_plain, $demo_role);
    mysqli_stmt_execute($stmt_insert);
    mysqli_stmt_close($stmt_insert);
}
mysqli_stmt_close($stmt_check);

// ---------------- LOGIN HANDLING ---------------- //
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_SESSION['login_attempts'] >= 5) {
        $err = "Too many failed attempts. Please try again after 10 minutes.";
    } else {
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'];
        $csrf_token = $_POST['csrf_token'];

        if (!hash_equals($_SESSION['csrf_token'], $csrf_token)) {
            $err = "Invalid session. Please refresh and try again.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = "Invalid email format.";
        } else {
            $stmt = mysqli_prepare($conn, "SELECT id, name, password, role FROM users WHERE email=?");
            mysqli_stmt_bind_param($stmt, 's', $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $uid, $uname, $upass, $urole);

            if (mysqli_stmt_fetch($stmt)) {
                $is_demo = ($email === $demo_email);
                $valid = $is_demo ? hash_equals($password, $upass) : password_verify($password, $upass);

                if ($valid) {
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $uid;
                    $_SESSION['user_name'] = $uname;
                    $_SESSION['role'] = $urole;
                    $_SESSION['login_attempts'] = 0;
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                    if ($urole === 'driver') {
                        header('Location: driver_dashboard.php');
                    } else {
                        header('Location: index.php');
                    }
                    exit;
                } else {
                    $err = "Incorrect email or password.";
                    $_SESSION['login_attempts']++;
                    $_SESSION['last_attempt_time'] = time();
                }
            } else {
                $err = "Incorrect email or password.";
            }
            mysqli_stmt_close($stmt);
        }
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>AmbuFinder — Login</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
    font-family:'Poppins',sans-serif;
    background:#ffffff;
    margin:0;
    padding:30px;
    color:#333;
}
.logo-container { text-align:center; margin-bottom:20px; }
.logo-container img {
    width:150px; height:150px; object-fit:cover;
    border-radius:50%; border:3px solid #fff;
    box-shadow:0 4px 12px rgba(0,0,0,0.2);
}
.card {
    max-width:400px; margin:0 auto; background:#fff; padding:30px;
    border-radius:12px; box-shadow:0 6px 20px rgba(0,0,0,0.1);
}
h2 { color:#dc3545; margin-top:0; text-align:center; }
input {
    width:100%; padding:12px; margin:8px 0;
    border-radius:8px; border:1px solid #ccc; font-size:15px;
}
button {
    background:#dc3545; color:#fff; padding:12px;
    width:100%; border:none; border-radius:8px;
    cursor:pointer; font-weight:600; font-size:16px;
}
button:hover { background:#b71c1c; }
.error { color:#b00020; margin-bottom:10px; text-align:center; }
.success { color:green; margin-bottom:10px; text-align:center; }
.signup-link { text-align:center; margin-top:15px; }
.signup-link a { color:#dc3545; text-decoration:none; font-weight:600; }
.signup-link a:hover { text-decoration:underline; }

.google-btn {
    background:#fff;
    color:#444;
    border:1px solid #ccc;
    padding:10px;
    border-radius:8px;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    font-weight:600;
    width:100%;
    cursor:pointer;
    margin-top:10px;
    box-shadow:0 2px 6px rgba(0,0,0,0.1);
}
.google-btn:hover { background:#f7f7f7; }
.google-btn img {
    width:20px;
    height:20px;
}
.or-divider {
    text-align:center;
    margin:15px 0;
    font-weight:600;
    color:#888;
    position:relative;
}
.or-divider::before, .or-divider::after {
    content:'';
    position:absolute;
    top:50%;
    width:40%;
    height:1px;
    background:#ddd;
}
.or-divider::before { left:0; }
.or-divider::after { right:0; }
</style>
</head>
<body>

<div class="logo-container">
    <img src="AmbuFinder_LOGO.png" alt="AmbuFinder Logo">
</div>

<div class="card">
<h2>Login</h2>
<?php 
if($err) echo "<div class='error'>" . htmlspecialchars($err) . "</div>"; 
if($success) echo "<div class='success'>" . htmlspecialchars($success) . "</div>"; 
?>
<form method="post">
<input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
<input type="email" name="email" placeholder="Email" value="<?php echo $demo_email; ?>" required>
<input type="password" name="password" placeholder="Password" value="<?php echo $demo_password_plain; ?>" required>
<button type="submit">Login</button>
</form>

<div class="or-divider">OR</div>

<a href="google_login.php" class="google-btn">
    <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google Icon">
    Continue with Google
</a>

<div class="signup-link">
<p>Don't have an account? <a href="register.php">Sign up</a></p>
</div>
</div>

</body>
</html>
