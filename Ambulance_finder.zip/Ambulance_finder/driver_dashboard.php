<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
if ($_SESSION['role'] !== 'driver') {
    header("Location: index.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Driver Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { font-family:'Poppins',sans-serif; margin:0; padding:20px; background:#f7f7f7; }
h1 { color:#dc3545; }
.card {
    background:#fff; padding:20px; border-radius:12px;
    box-shadow:0 6px 20px rgba(0,0,0,0.1); max-width:600px; margin:0 auto;
}
</style>
</head>
<body>
<div class="card">
    <h1>Welcome, <?php echo $_SESSION['user_name']; ?> 🚑</h1>
    <p>You are logged in as an <b>Ambulance Driver</b>.</p>
    <p>This is your driver dashboard. You can add features like:</p>
    <ul>
        <li>View booking requests</li>
        <li>Accept or reject rides</li>
        <li>Update your availability</li>
    </ul>
    <p><a href="logout.php">Logout</a></p>
</div>
</body>
</html>
